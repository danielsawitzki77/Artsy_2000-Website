@echo off
title Buck-Fifty Innovation Labs - Artsy_2000 Setup Wizard v1.0
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "%~dp0DATA\SETUP.PS1"
