==============================================================================
        ARTSY_2000 (TM) v1.0  --  AD-SUPPORTED FREE EDITION (.ZIP)
                BUCK-FIFTY INNOVATION LABS, INC. (EST. 1993)
                    *** PLEASE READ THIS FILE FIRST! ***
==============================================================================

  CONGRATULATIONS, SUBJECT 13!
  Thank you for downloading the 100% FREE Ad-Supported Edition of Artsy_2000,
  generously subsidized by Buck-Fifty Innovation Labs' finest 1996 consumer
  products (Slab-O-Bull Beef Jerky, Fissi-Efficient Home Reactors, Omni-Smile
  Domestic Capsules, Spyk-Os Cereal, and the unstoppable B-50 4x4 Truck)!

  CONTENTS OF THIS ARCHIVE:
    SETUP_v1.0.BAT    Double-click to launch the Artsy_2000 Setup Wizard v1.0
    README.TXT        This manual, DOS tuning tips & troubleshooting guide
    DATA\             Archived 1.44 MB diskette image data & sponsor ads

==============================================================================
  0. HOW TO RUN & WHERE TO GET THE FULL AD-FREE STEAM RELEASE
==============================================================================

  HOW TO LAUNCH THE 1996 AD-SUPPORTED INSTALLER:
    1. Extract ALL files from Artsy_2000_Setup_v1.0.zip into a normal folder.
    2. Double-click SETUP_v1.0.BAT in File Explorer!
       (Runs natively on Windows 10 & Windows 11 -- no unsigned .exe needed.)

  WANT THE UNCORRUPTED, AD-FREE FULL VERSION OF ARTSY_2000?
  +------------------------------------------------------------------------+
  |  GET ARTSY_2000 ON STEAM (0% GPU REQUIRED -- ONLY A BUCK FIFTY!):      |
  |                                                                        |
  |      https://store.steampowered.com/app/5641470/Artsy_2000/            |
  +------------------------------------------------------------------------+

==============================================================================
  1. IMPORTANT: MAKE A SAFETY BACKUP COPY ONTO A 3.5" FLOPPY DISKETTE!
==============================================================================

  True 1996 computer enthusiasts ALWAYS archive downloaded shareware onto
  physical magnetic media before installing:

    1. Copy SETUP_v1.0.BAT, README.TXT, and the DATA\ folder onto a blank,
       formatted 3.5" 1.44 MB High-Density diskette (Drive A:\).
    2. Slide the write-protect tab to OPEN and run:

           C:\> DISKCOPY A: A:

    3. Label your safety copy with a soft felt-tip pen (ballpoint pens can
       crush magnetic oxide sectors!) and store it far away from fridge
       magnets, 14" CRT degauss coils, microwave ovens, and damp Sub-Level 4
       filing cabinets where 30-year magnetic flux decay strikes hardest!

==============================================================================
  2. MINIMUM WORKSTATION REQUIREMENTS (1996 CERTIFIED)
==============================================================================

  Verify your IBM-compatible personal computer meets these rigorous specs
  (identical to the Automatic Hardware Audit inside SETUP_v1.0.BAT):

    PROCESSOR : Intel 486DX2/66 MHz (Pentium 90 MHz Recommended!)
    MEMORY    : 4 MB Extended RAM (608 KB Conventional Memory FREE!)
    GRAPHICS  : 256-Color Super VGA (0% 3D GPU Required! Pure CPU Silicon!)
    DISPLAY   : 14" Curved Beige CRT (Slight Radiation Hum Normal)
    HARD DISK : 14.2 MB Contiguous Magnetic Sectors on Drive C:\
    FLOPPY    : 3.5" 1.44 MB High-Density Drive (Drive A:\)
    SOUND     : Sound Blaster 16 / AWE32, AdLib OPL2, Gravis UltraSound MAX,
                or Internal PC Piezo Speaker (1-Bit Ear-Piercing Mode)
    MOUSE     : 2-Button Mechanical Ball Mouse (Lint-Free Rollers!)
    MODEM     : 14.4k / 28.8k Baud (For Future S.T.E.A.M. Connectivity)
    OS        : MS-DOS 6.22 / Windows 3.11 / Windows 95
                (Also tested on modern Windows 10 & Windows 11 64-bit!)

==============================================================================
  3. EXTENDED MEMORY (XMS/EMS), CONFIG.SYS & AUTOEXEC.BAT TUNING
==============================================================================

  Artsy_2000 requires at least 608 KB of free Conventional Memory below the
  640 KB barrier, plus HIMEM.SYS Extended Memory (XMS). If your PC locks up
  or displays "OUT OF CONVENTIONAL MEMORY", edit C:\CONFIG.SYS and
  C:\AUTOEXEC.BAT using MS-DOS EDIT (or run MEMMAKER) to match below:

  --- RECOMMENDED C:\CONFIG.SYS ---
    DEVICE=C:\DOS\HIMEM.SYS
    DEVICE=C:\DOS\EMM386.EXE RAM NOEMS
    DOS=HIGH,UMB
    FILES=60
    BUFFERS=30
    DEVICEHIGH=C:\BUCK50\CRANIAL.SYS /FIXATE=CALM

  --- RECOMMENDED C:\AUTOEXEC.BAT ---
    SET BLASTER=A220 I5 D1 H5 P330 T6
    LH C:\MOUSE\MOUSE.COM /R2
    LH C:\DOS\MSCDEX.EXE /D:B50CD001
    SET PERDIEM=1.50

  MEMORY TIPS FROM SUB-LEVEL 4 SYSTEMS ENGINEERING:
    * Load your mouse driver (CuteMouse v1.9 uses only 3 KB!) and CD-ROM
      extensions into Upper Memory Blocks (UMBs) using LH / DEVICEHIGH.
    * Disable SMARTDRV write-behind caching if your power flickers whenever
      your neighbor boots up their Fissi-Efficient(TM) Home Reactor.
    * Do NOT run Stacker, DoubleSpace, or QEMM-386 alongside CRANIAL.SYS,
      or Dr. Brad Vance may appear twice on the same scanline.
    * If all else fails, press F5 at "Starting MS-DOS..." for a Clean Boot!

==============================================================================
  4. TROUBLESHOOTING & KNOWN ISSUES
==============================================================================

  Q: Setup ignored my custom folder and insisted on C:\Games\Artsy_2000!
  A: Standard Sub-Level 4 Executive Override Policy #19-B. Do not resist.

  Q: Setup warned it was deleting Solitaire, Minesweeper, and TAXES_1996.DOC!
  A: Relax, Subject 13! SETUP_v1.0.BAT is an authentic 1996 comedy simulation.
     It NEVER creates, modifies, shreds, or defragments any files on your PC.

  Q: The installation bar says 5 minutes remaining! Is my 486 too slow?
  A: Try pressing the big golden "SPEED UP!" button on the Setup window.
     (More than once. Much more than once.)

  Q: I selected Sound Blaster 16 and now smell faint ozone!
  A: Verify your Port/IRQ/DMA jumpers match SET BLASTER=A220 I5 D1 H5 P330 T6.
     Avoid IRQ 7 if your dot-matrix printer is connected to LPT1, and NEVER
     choose IRQ 2 (Panic). Check "Mute PC Speaker Beeps" if your cat hisses.

  Q: My mouse cursor drifts sideways during 8-Verb Brain Surgery!
  A: Twist the retaining ring on the underside of your mouse, pop out the
     rubber ball, and scrape accumulated gray lint off the two internal
     plastic rollers using a fingernail or clean butter knife.

  Q: Setup failed at 99.4% with CRITICAL DISK ERROR 0xB50 on DATA\GAME.DAT!
  A: Sadly, 30 years of Sub-Level 4 magnetic decay corrupted our free 1996
     archival image! Grab the clean, ad-free full release on Steam here:
     https://store.steampowered.com/app/5641470/Artsy_2000/
     (Hey buddy -- it's only a buck fifty anyways, am I right?)

  Q: Clicking "Cancel" gave me a horrifying CANCEL.DLL (0xDEAD-B50) error!
  A: Buck-Fifty strongly discourages quitting science. (The upper-right [X]
     button always exits immediately if you truly must abandon your $1.50.)

==============================================================================
  5. STUCK IN SUB-LEVEL 4? CALL THE OFFICIAL 1-900 GAMEPLAY HINT LINE!
==============================================================================

  Can't outrun the Fibonacci Spiked Sphere? Confused by Dr. Sterling's Pre-Op
  audit? Call our automated 24-hour Hint & Cognitive Advice Hotline!

       >>>  1-900-555-B500  (1-900-555-2500)  <<<
       [ OBVIOUSLY FAKE 555 NUMBER -- DO NOT ACTUALLY DIAL! ]

  Rates: $1.50 for the first minute, $0.99 each additional minute (plus one
  non-refundable Personal Pan Pizza convenience fee). Touch-tone phone req'd!
  KIDS: Always ask your parents' permission before calling!

    Press 1 -- Spiked Sphere Chase 3D survival & cornering secrets
    Press 2 -- How to pass all 5 CRT Interrogations without getting clamped
    Press 3 -- Emergency replacement for stale Slab-O-Bull(TM) Beef Jerky
    Press 4 -- If your 14" beige CRT has begun humming in D-minor

==============================================================================
  6. CONTACTING BUCK-FIFTY INNOVATION LABS (MAILING ADDRESS)
==============================================================================

  For technical support, warranty claims, $1.50 Per Diem reimbursement, or
  Personal Pan Pizza Voucher disputes, direct all physical correspondence to:

      BUCK-FIFTY INNOVATION LABS, INC.
      Sub-Level 4 Intake & Mailroom (Site Alpha-4)
      GPS Coordinates: 40 deg 40'34.3"N, 112 deg 06'43.7"W
                       (Decimal: 40.676194, -112.112139)

  (IMPORTANT: Do NOT write a street address on your envelope. Simply print
   the GPS coordinates in clear block capitals and instruct your postal
   carrier to knock three times on the unmarked concrete blast hatch.)

  WORLD WIDE WEB : https://buckfiftylabs.com
  STEAM STORE    : https://store.steampowered.com/app/5641470/Artsy_2000/
  STEAM APP ID   : 5641470

  "Where the Mind Meets the Machine." -- Remain calm while fixated.
==============================================================================
