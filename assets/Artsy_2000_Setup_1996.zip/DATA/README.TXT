==============================================================================
         ARTSY_2000 — 1996 AD-SUPPORTED FREE EDITION (WEB INSTALLER)
                  BUCK-FIFTY INNOVATION LABS (EST. 1993)
==============================================================================

  CONTENTS OF THIS ARCHIVE:
    SETUP.BAT                 Double-click to launch the 1996 Setup Wizard!
    DATA\SETUP.PS1            Windows PowerShell Win95/3.1 Setup UI
    DATA\GAME.DAT             Archived Sub-Level 4 magnetic data file (~1 MB)
    DATA\AD_01..08.PNG        Mandatory Buck-Fifty Innovation Labs sponsor ads
    DATA\*.PNG                Retro bitmap artwork for the Setup Wizard
    DATA\README.TXT           This quick-start file

  HOW TO RUN:
    Extract the archive and double-click SETUP.BAT in File Explorer!
    (No unsigned .exe required — runs natively on Windows 10 & Windows 11.)

  NOTE TO SUBJECT 13:
    This "Ad-Supported Free Edition" installer is an authentic 1996 comedy
    simulation. It DOES NOT delete any files, defragment your drive, or modify
    CONFIG.SYS / AUTOEXEC.BAT. Enjoy the cycling Buck-Fifty product ads while
    the 30-year-old magnetic archive inevitably fails at 99.4% — and then
    click the S.T.E.A.M. banner to grab the real game (it's only $1.50!).

  STEAM STORE   : https://store.steampowered.com/app/5641470/
  OFFICIAL LABS : https://buckfiftylabs.com
==============================================================================
