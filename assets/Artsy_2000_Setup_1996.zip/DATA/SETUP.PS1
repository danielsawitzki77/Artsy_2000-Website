﻿# ==============================================================================
# Artsy_2000 - Classic 1996 Diskette Setup Wizard (Buck-Fifty Innovation Labs)
# Native Windows PowerShell 5.1 + WinForms (No unsigned EXE required!)
# Safe comedy simulation: NEVER creates, modifies, or deletes any user files!
# ==============================================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Enforce authentic classic Windows 95 / 3.1 3D beveled controls (no modern Aero/Win11 flat styles)
[System.Windows.Forms.Application]::VisualStyleState = [System.Windows.Forms.VisualStyles.VisualStyleState]::NoneEnabled

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir   = $ScriptDir
$DiskRoot  = Split-Path -Parent $ScriptDir

$SteamStoreUrl = "https://store.steampowered.com/app/5641470/"

# ---- Helper: Load image safely from DATA\ via MemoryStream (never locks files on disk!) ----
function Load-DiskImage([string]$fileName) {
    $p = Join-Path $DataDir $fileName
    if (Test-Path $p) {
        $bytes = [System.IO.File]::ReadAllBytes($p)
        $ms = New-Object System.IO.MemoryStream(,$bytes)
        return [System.Drawing.Image]::FromStream($ms)
    }
    return $null
}

$ImgSidebar  = Load-DiskImage "SIDEBAR.PNG"
$ImgBanner   = Load-DiskImage "BANNER.PNG"
$ImgSteamBtn = Load-DiskImage "STEAM_STORE_BTN.PNG"

# Load cycling Buck-Fifty Sponsored Product Ads (AD_01.PNG .. AD_08.PNG)
$AdImages = @()
for ($a = 1; $a -le 12; $a++) {
    $adName = ("AD_{0:D2}.PNG" -f $a)
    $adImg = Load-DiskImage $adName
    if ($null -ne $adImg) {
        $AdImages += $adImg
    }
}

# ---- Classic Win95 Palette & Fonts ----
$ColBg      = [System.Drawing.Color]::FromArgb(192, 192, 192)
$ColNavy    = [System.Drawing.Color]::FromArgb(0, 0, 128)
$ColDarkTxt = [System.Drawing.Color]::FromArgb(16, 16, 16)
$ColMuted   = [System.Drawing.Color]::FromArgb(64, 64, 64)
$ColWhite   = [System.Drawing.Color]::White

$FontUi      = New-Object System.Drawing.Font("MS Sans Serif", 8.25, [System.Drawing.FontStyle]::Regular)
$FontUiBold  = New-Object System.Drawing.Font("MS Sans Serif", 8.25, [System.Drawing.FontStyle]::Bold)
$FontTitle   = New-Object System.Drawing.Font("MS Sans Serif", 11.5, [System.Drawing.FontStyle]::Bold)
$FontMono    = New-Object System.Drawing.Font("Courier New", 8.0, [System.Drawing.FontStyle]::Regular)
$FontMonoB   = New-Object System.Drawing.Font("Courier New", 8.5, [System.Drawing.FontStyle]::Bold)
$FontMonoSm  = New-Object System.Drawing.Font("Courier New", 7.4, [System.Drawing.FontStyle]::Bold)
$FontKeyBig  = New-Object System.Drawing.Font("Courier New", 16.5, [System.Drawing.FontStyle]::Bold)
$FontSmall   = New-Object System.Drawing.Font("MS Sans Serif", 7.5, [System.Drawing.FontStyle]::Regular)

# ---- Main Classic Win95 Setup Form (796 x 474 -> Symmetric Left Artsy Sidebar + Center Body + Right Ad Panel!) ----
$Form = New-Object System.Windows.Forms.Form
$Form.Text = "Artsy_2000 Setup - Buck-Fifty Innovation Labs (Ad-Supported Free Edition)"
$Form.ClientSize = New-Object System.Drawing.Size(796, 474)
$Form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$Form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$Form.MaximizeBox = $false
$Form.MinimizeBox = $true
$Form.BackColor = $ColBg
$Form.Font = $FontUi

# Optional crisp PC Speaker retro beep (never crashes if audio unavailable)
$script:MuteBeeps = $false
function Invoke-RetroBeep([int]$freq, [int]$ms) {
    if (-not $script:MuteBeeps) {
        try { [System.Console]::Beep($freq, $ms) } catch {}
    }
}

# ---- Top Banner Strip (776 x 62 Fixed3D -> exact 772 x 58 1:1 interior) ----
$PicBanner = New-Object System.Windows.Forms.PictureBox
$PicBanner.Location = New-Object System.Drawing.Point(10, 8)
$PicBanner.Size = New-Object System.Drawing.Size(776, 62)
$PicBanner.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$PicBanner.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
if ($ImgBanner) { $PicBanner.Image = $ImgBanner }
$Form.Controls.Add($PicBanner)

# ---- Left Sidebar Graphic (164 x 344 Fixed3D -> exact 160 x 340 1:1 interior; visible on Pages 0..3) ----
$PicSidebar = New-Object System.Windows.Forms.PictureBox
$PicSidebar.Location = New-Object System.Drawing.Point(10, 78)
$PicSidebar.Size = New-Object System.Drawing.Size(164, 344)
$PicSidebar.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$PicSidebar.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
if ($ImgSidebar) { $PicSidebar.Image = $ImgSidebar }
$Form.Controls.Add($PicSidebar)

# ---- Right Symmetric Cycling Buck-Fifty Ad Panel (164 x 344 Fixed3D -> exact 160 x 340; visible on Page 3!) ----
$PicAdSidebar = New-Object System.Windows.Forms.PictureBox
$PicAdSidebar.Location = New-Object System.Drawing.Point(622, 78)
$PicAdSidebar.Size = New-Object System.Drawing.Size(164, 344)
$PicAdSidebar.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$PicAdSidebar.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
$PicAdSidebar.Cursor = [System.Windows.Forms.Cursors]::Hand
$PicAdSidebar.Visible = $false
if ($AdImages.Count -gt 0) { $PicAdSidebar.Image = $AdImages[0] }
$AdToolTip = New-Object System.Windows.Forms.ToolTip
$AdToolTip.SetToolTip($PicAdSidebar, "Buck-Fifty Innovation Labs Sponsor — Click to cycle to next ad!")
$Form.Controls.Add($PicAdSidebar)

# ---- Bottom Classic 3D Separator Line ----
$SepLine = New-Object System.Windows.Forms.Label
$SepLine.Location = New-Object System.Drawing.Point(10, 429)
$SepLine.Size = New-Object System.Drawing.Size(776, 2)
$SepLine.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$Form.Controls.Add($SepLine)

# ---- Bottom Status & Wizard Navigation Buttons ----
$LblFooterVer = New-Object System.Windows.Forms.Label
$LblFooterVer.Location = New-Object System.Drawing.Point(12, 444)
$LblFooterVer.Size = New-Object System.Drawing.Size(340, 18)
$LblFooterVer.ForeColor = $ColMuted
$LblFooterVer.Font = $FontSmall
$LblFooterVer.Text = "Buck-Fifty Ad-Supported Freeware Engine v3.11 (1996)"
$Form.Controls.Add($LblFooterVer)

$BtnBack = New-Object System.Windows.Forms.Button
$BtnBack.Text = "< &Back"
$BtnBack.Location = New-Object System.Drawing.Point(508, 439)
$BtnBack.Size = New-Object System.Drawing.Size(84, 26)
$Form.Controls.Add($BtnBack)

$BtnNext = New-Object System.Windows.Forms.Button
$BtnNext.Text = "&Next >"
$BtnNext.Location = New-Object System.Drawing.Point(596, 439)
$BtnNext.Size = New-Object System.Drawing.Size(96, 26)
$Form.Controls.Add($BtnNext)

$BtnCancel = New-Object System.Windows.Forms.Button
$BtnCancel.Text = "Cancel"
$BtnCancel.Location = New-Object System.Drawing.Point(702, 439)
$BtnCancel.Size = New-Object System.Drawing.Size(84, 26)
$Form.Controls.Add($BtnCancel)

# Helper to create wizard page containers ("wizard" = right of left sidebar, "center" = flanked by both sidebars, "full" = full width)
function New-PagePanel([string]$layoutMode = "wizard") {
    $p = New-Object System.Windows.Forms.Panel
    switch ($layoutMode) {
        "full" {
            $p.Location = New-Object System.Drawing.Point(10, 78)
            $p.Size = New-Object System.Drawing.Size(776, 344)
        }
        "center" {
            $p.Location = New-Object System.Drawing.Point(182, 78)
            $p.Size = New-Object System.Drawing.Size(432, 344)
        }
        default {
            $p.Location = New-Object System.Drawing.Point(182, 78)
            $p.Size = New-Object System.Drawing.Size(604, 344)
        }
    }
    $p.BackColor = $ColBg
    $p.Visible = $false
    $Form.Controls.Add($p)
    return $p
}

# ==============================================================================
# PAGE 0: WELCOME & 1996 HARDWARE REQUIREMENTS
# ==============================================================================
$Page0 = New-PagePanel "wizard"

$LblP0Title = New-Object System.Windows.Forms.Label
$LblP0Title.Location = New-Object System.Drawing.Point(4, 2)
$LblP0Title.Size = New-Object System.Drawing.Size(596, 24)
$LblP0Title.Font = $FontTitle
$LblP0Title.ForeColor = $ColNavy
$LblP0Title.Text = "Welcome to Artsy_2000 (Ad-Supported Free Edition)!"
$Page0.Controls.Add($LblP0Title)

$LblP0Intro = New-Object System.Windows.Forms.Label
$LblP0Intro.Location = New-Object System.Drawing.Point(4, 30)
$LblP0Intro.Size = New-Object System.Drawing.Size(596, 62)
$LblP0Intro.Text = "Congratulations, Subject 13! You are installing the 100% FREE Ad-Supported Edition of Artsy_2000, generously subsidized by Buck-Fifty Innovation Labs' finest 1996 consumer products!`r`n`r`nSimply sit back, enjoy our mandatory sponsor showcases during setup, and verify your 1996 hardware specs below."
$Page0.Controls.Add($LblP0Intro)

$GrpSpecs = New-Object System.Windows.Forms.GroupBox
$GrpSpecs.Location = New-Object System.Drawing.Point(4, 96)
$GrpSpecs.Size = New-Object System.Drawing.Size(596, 166)
$GrpSpecs.Text = " Minimum Workstation Requirements (1996 Certified) "
$GrpSpecs.Font = $FontUiBold
$Page0.Controls.Add($GrpSpecs)

$TxtSpecs = New-Object System.Windows.Forms.TextBox
$TxtSpecs.Location = New-Object System.Drawing.Point(10, 18)
$TxtSpecs.Size = New-Object System.Drawing.Size(576, 138)
$TxtSpecs.Multiline = $true
$TxtSpecs.ReadOnly = $true
$TxtSpecs.WordWrap = $false
$TxtSpecs.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 236)
$TxtSpecs.Font = New-Object System.Drawing.Font("Courier New", 8.2, [System.Drawing.FontStyle]::Regular)
$TxtSpecs.Text = @(
    'PROCESSOR : Intel 486DX2/66 MHz (Pentium 90 Recommended!)',
    'MEMORY    : 4 MB Extended RAM (608 KB Conventional Free)',
    'GRAPHICS  : 256-Color Super VGA (0% 3D GPU Required!)',
    'DISPLAY   : 14" Curved Beige CRT (Slight Radiation Hum)',
    'HARD DISK : 14.2 MB Contiguous Magnetic Sectors on C:\',
    'FLOPPY    : 3.5" 1.44 MB High-Density Drive (Drive A:\)',
    'MOUSE     : 2-Button Mechanical Ball Mouse (Lint-Free)',
    'MODEM     : 14.4k / 28.8k Baud (For Future S.T.E.A.M.)'
) -join "`r`n"
$GrpSpecs.Controls.Add($TxtSpecs)

$GrpProbe = New-Object System.Windows.Forms.GroupBox
$GrpProbe.Location = New-Object System.Drawing.Point(4, 266)
$GrpProbe.Size = New-Object System.Drawing.Size(596, 74)
$GrpProbe.Text = " Automatic Hardware Audit "
$GrpProbe.Font = $FontUiBold
$Page0.Controls.Add($GrpProbe)

$LblProbe = New-Object System.Windows.Forms.Label
$LblProbe.Location = New-Object System.Drawing.Point(10, 17)
$LblProbe.Size = New-Object System.Drawing.Size(576, 52)
$LblProbe.Font = New-Object System.Drawing.Font("Courier New", 8.0, [System.Drawing.FontStyle]::Bold)
$LblProbe.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 0)
$LblProbe.UseMnemonic = $false
$LblProbe.Text = @(
    '[OK] Futuristic CPU detected -> Throttling to 66 MHz...',
    '[OK] Excessive RAM detected -> Hiding 99.9% via HIMEM.SYS',
    '[OK] Per Diem Authorized: $1.50 + 1x Personal Pan Pizza'
) -join "`r`n"
$GrpProbe.Controls.Add($LblProbe)

# ==============================================================================
# PAGE 1: DESTINATION DIRECTORY + CONFIG.SYS / AUTOEXEC.BAT ADVICE
# ==============================================================================
$Page1 = New-PagePanel "wizard"

$LblP1Title = New-Object System.Windows.Forms.Label
$LblP1Title.Location = New-Object System.Drawing.Point(4, 2)
$LblP1Title.Size = New-Object System.Drawing.Size(596, 24)
$LblP1Title.Font = $FontTitle
$LblP1Title.ForeColor = $ColNavy
$LblP1Title.UseMnemonic = $false
$LblP1Title.Text = "Choose Destination Path & DOS Memory Tuning"
$Page1.Controls.Add($LblP1Title)

$GrpPath = New-Object System.Windows.Forms.GroupBox
$GrpPath.Location = New-Object System.Drawing.Point(4, 30)
$GrpPath.Size = New-Object System.Drawing.Size(596, 74)
$GrpPath.Text = " Destination Directory "
$GrpPath.Font = $FontUiBold
$Page1.Controls.Add($GrpPath)

$LblPathNote = New-Object System.Windows.Forms.Label
$LblPathNote.Location = New-Object System.Drawing.Point(10, 18)
$LblPathNote.Size = New-Object System.Drawing.Size(576, 16)
$LblPathNote.Font = $FontUi
$LblPathNote.Text = "Setup will install Artsy_2000 into the following folder (you may change it):"
$GrpPath.Controls.Add($LblPathNote)

$TxtPath = New-Object System.Windows.Forms.TextBox
$TxtPath.Location = New-Object System.Drawing.Point(10, 40)
$TxtPath.Size = New-Object System.Drawing.Size(486, 22)
$TxtPath.Font = $FontMonoB
$TxtPath.Text = "C:\Games\Artsy_2000"
$GrpPath.Controls.Add($TxtPath)

$BtnBrowse = New-Object System.Windows.Forms.Button
$BtnBrowse.Location = New-Object System.Drawing.Point(502, 39)
$BtnBrowse.Size = New-Object System.Drawing.Size(84, 24)
$BtnBrowse.Font = $FontUi
$BtnBrowse.Text = "B&rowse..."
$BtnBrowse.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    $fbd.Description = "Select installation folder for Artsy_2000 (totally respected, we promise):"
    if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $TxtPath.Text = $fbd.SelectedPath
    }
})
$GrpPath.Controls.Add($BtnBrowse)

$GrpDos = New-Object System.Windows.Forms.GroupBox
$GrpDos.Location = New-Object System.Drawing.Point(4, 110)
$GrpDos.Size = New-Object System.Drawing.Size(596, 198)
$GrpDos.Text = " Mandatory CONFIG.SYS && AUTOEXEC.BAT Advice "
$GrpDos.Font = $FontUiBold
$Page1.Controls.Add($GrpDos)

$TxtDos = New-Object System.Windows.Forms.TextBox
$TxtDos.Location = New-Object System.Drawing.Point(10, 20)
$TxtDos.Size = New-Object System.Drawing.Size(576, 168)
$TxtDos.Multiline = $true
$TxtDos.ReadOnly = $true
$TxtDos.WordWrap = $false
$TxtDos.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$TxtDos.BackColor = [System.Drawing.Color]::FromArgb(12, 20, 42)
$TxtDos.ForeColor = [System.Drawing.Color]::FromArgb(80, 255, 140)
$TxtDos.Font = $FontMono
$TxtDos.Text = @(
    '--- RECOMMENDED C:\CONFIG.SYS ---',
    'DEVICE=C:\DOS\HIMEM.SYS',
    'DEVICE=C:\DOS\EMM386.EXE RAM NOEMS',
    'DOS=HIGH,UMB',
    'FILES=60',
    'BUFFERS=30',
    'DEVICEHIGH=C:\BUCK50\CRANIAL.SYS /FIXATE=CALM',
    '',
    '--- RECOMMENDED C:\AUTOEXEC.BAT ---',
    'SET BLASTER=A220 I5 D1 H5 P330 T6',
    'LH C:\MOUSE\MOUSE.COM /R2',
    'LH C:\DOS\MSCDEX.EXE /D:B50CD001',
    'SET PERDIEM=1.50'
) -join "`r`n"
$GrpDos.Controls.Add($TxtDos)

$ChkOverwrite = New-Object System.Windows.Forms.CheckBox
$ChkOverwrite.Location = New-Object System.Drawing.Point(8, 314)
$ChkOverwrite.Size = New-Object System.Drawing.Size(588, 22)
$ChkOverwrite.Checked = $true
$ChkOverwrite.UseMnemonic = $false
$ChkOverwrite.Text = "Auto-overwrite CONFIG.SYS & AUTOEXEC.BAT without backup (Legal OK)"
$Page1.Controls.Add($ChkOverwrite)

# ==============================================================================
# PAGE 2: SOUND CARD, IRQ/DMA, MOUSE DRIVER & CRT SETTINGS
# ==============================================================================
$Page2 = New-PagePanel "wizard"

$LblP2Title = New-Object System.Windows.Forms.Label
$LblP2Title.Location = New-Object System.Drawing.Point(4, 2)
$LblP2Title.Size = New-Object System.Drawing.Size(596, 24)
$LblP2Title.Font = $FontTitle
$LblP2Title.ForeColor = $ColNavy
$LblP2Title.UseMnemonic = $false
$LblP2Title.Text = "Hardware Drivers: Sound Card, IRQ & Mouse"
$Page2.Controls.Add($LblP2Title)

$GrpSound = New-Object System.Windows.Forms.GroupBox
$GrpSound.Location = New-Object System.Drawing.Point(4, 28)
$GrpSound.Size = New-Object System.Drawing.Size(596, 166)
$GrpSound.Text = " Select Digital Audio / FM Synthesizer Card "
$GrpSound.Font = $FontUiBold
$Page2.Controls.Add($GrpSound)

$SoundOptions = @(
    "Sound Blaster 16 / AWE32 (Warning: May Permanently Fry Card)",
    "AdLib Music Synthesizer Card (1987 Classic OPL2)",
    "Gravis UltraSound MAX (For True Demoscene Elitists)",
    "PC Internal Piezo Speaker (1-Bit Ear-Piercing Mode)",
    "No Sound (Dr. Vance Will Hum Quietly Into Your Mic)"
)
$SoundRadios = @()
for ($i = 0; $i -lt $SoundOptions.Count; $i++) {
    $rb = New-Object System.Windows.Forms.RadioButton
    $rb.Location = New-Object System.Drawing.Point(12, (20 + $i * 21))
    $rb.Size = New-Object System.Drawing.Size(570, 19)
    $rb.Font = $FontUi
    $rb.Text = $SoundOptions[$i]
    if ($i -eq 0) { $rb.Checked = $true }
    $GrpSound.Controls.Add($rb)
    $SoundRadios += $rb
}

# Port / IRQ / DMA Dropdowns + Test Sound button
$LblPort = New-Object System.Windows.Forms.Label
$LblPort.Location = New-Object System.Drawing.Point(12, 134)
$LblPort.Size = New-Object System.Drawing.Size(36, 18)
$LblPort.Font = $FontUi; $LblPort.Text = "Port:"
$GrpSound.Controls.Add($LblPort)

$CmbPort = New-Object System.Windows.Forms.ComboBox
$CmbPort.Location = New-Object System.Drawing.Point(48, 130)
$CmbPort.Size = New-Object System.Drawing.Size(70, 22)
$CmbPort.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$CmbPort.Font = $FontUi
[void]$CmbPort.Items.AddRange(@("220h", "240h", "260h"))
$CmbPort.SelectedIndex = 0
$GrpSound.Controls.Add($CmbPort)

$LblIrq = New-Object System.Windows.Forms.Label
$LblIrq.Location = New-Object System.Drawing.Point(132, 134)
$LblIrq.Size = New-Object System.Drawing.Size(32, 18)
$LblIrq.Font = $FontUi; $LblIrq.Text = "IRQ:"
$GrpSound.Controls.Add($LblIrq)

$CmbIrq = New-Object System.Windows.Forms.ComboBox
$CmbIrq.Location = New-Object System.Drawing.Point(164, 130)
$CmbIrq.Size = New-Object System.Drawing.Size(96, 22)
$CmbIrq.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$CmbIrq.Font = $FontUi
[void]$CmbIrq.Items.AddRange(@("5 (OK)", "7 (LPT1!)", "2 (Panic)"))
$CmbIrq.SelectedIndex = 0
$GrpSound.Controls.Add($CmbIrq)

$LblDma = New-Object System.Windows.Forms.Label
$LblDma.Location = New-Object System.Drawing.Point(274, 134)
$LblDma.Size = New-Object System.Drawing.Size(38, 18)
$LblDma.Font = $FontUi; $LblDma.Text = "DMA:"
$GrpSound.Controls.Add($LblDma)

$CmbDma = New-Object System.Windows.Forms.ComboBox
$CmbDma.Location = New-Object System.Drawing.Point(312, 130)
$CmbDma.Size = New-Object System.Drawing.Size(60, 22)
$CmbDma.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$CmbDma.Font = $FontUi
[void]$CmbDma.Items.AddRange(@("1", "3", "5"))
$CmbDma.SelectedIndex = 0
$GrpSound.Controls.Add($CmbDma)

$BtnTestSnd = New-Object System.Windows.Forms.Button
$BtnTestSnd.Location = New-Object System.Drawing.Point(456, 129)
$BtnTestSnd.Size = New-Object System.Drawing.Size(126, 24)
$BtnTestSnd.Font = $FontUiBold
$BtnTestSnd.Text = "Test Sound!"
$BtnTestSnd.Add_Click({
    Invoke-RetroBeep 523 70
    Invoke-RetroBeep 659 70
    Invoke-RetroBeep 784 110
    [System.Windows.Forms.MessageBox]::Show(
        "Sound Blaster test complete!`r`nIf you heard glorious 8-bit synth bleeps (and smelled faint ozone), your IRQ is configured properly.",
        "Buck-Fifty Audio Diagnostics",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
})
$GrpSound.Controls.Add($BtnTestSnd)

# Mouse Driver GroupBox
$GrpMouse = New-Object System.Windows.Forms.GroupBox
$GrpMouse.Location = New-Object System.Drawing.Point(4, 200)
$GrpMouse.Size = New-Object System.Drawing.Size(596, 100)
$GrpMouse.Text = " Select Pointing Device Driver "
$GrpMouse.Font = $FontUiBold
$Page2.Controls.Add($GrpMouse)

$MouseOptions = @(
    "Microsoft Mouse Driver v8.20 (Serial COM1 - Clean Rubber Ball)",
    "Logitech MouseMan 3-Button (PS/2 Port)",
    "CuteMouse v1.9 (Ultra-Low 3 KB Conventional RAM)",
    "No Mouse (Navigate Sub-Level 4 Strictly via Telepathy)"
)
for ($i = 0; $i -lt $MouseOptions.Count; $i++) {
    $rbm = New-Object System.Windows.Forms.RadioButton
    $rbm.Location = New-Object System.Drawing.Point(12, (18 + $i * 19))
    $rbm.Size = New-Object System.Drawing.Size(570, 18)
    $rbm.Font = $FontUi
    $rbm.Text = $MouseOptions[$i]
    if ($i -eq 0) { $rbm.Checked = $true }
    $GrpMouse.Controls.Add($rbm)
}

$LblCrt = New-Object System.Windows.Forms.Label
$LblCrt.Location = New-Object System.Drawing.Point(6, 310)
$LblCrt.Size = New-Object System.Drawing.Size(130, 20)
$LblCrt.Font = $FontUiBold; $LblCrt.Text = "CRT Monitor Profile:"
$Page2.Controls.Add($LblCrt)

$CmbCrt = New-Object System.Windows.Forms.ComboBox
$CmbCrt.Location = New-Object System.Drawing.Point(138, 306)
$CmbCrt.Size = New-Object System.Drawing.Size(462, 22)
$CmbCrt.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$CmbCrt.Font = $FontUi
[void]$CmbCrt.Items.AddRange(@(
    '14" Beige Goldstar Curved CRT (Standard Sub-Level 4 Radiation)',
    '15" Packard Bell Multimedia Monitor w/ Clip-On Speakers',
    '17" Sony Trinitron (Heavy Enough to Crush Gov-Surplus Desk)'
))
$CmbCrt.SelectedIndex = 0
$Page2.Controls.Add($CmbCrt)

# ==============================================================================
# PAGE 3: HILARIOUS FAKE INSTALLER FLANKED BY LEFT ARTSY ART + RIGHT CYCLING ADS
#         (IGNORES PATH, UNSTOPPABLE SPACE CLEANUP, DEFRAG, 99.4% CORRUPT CRASH!)
# ==============================================================================
$Page3 = New-PagePanel "center"

$LblInstallHdr = New-Object System.Windows.Forms.Label
$LblInstallHdr.Location = New-Object System.Drawing.Point(0, 2)
$LblInstallHdr.Size = New-Object System.Drawing.Size(432, 22)
$LblInstallHdr.Font = $FontTitle
$LblInstallHdr.ForeColor = $ColNavy
$LblInstallHdr.Text = "Installing Artsy_2000 to C:\Games\Artsy_2000..."
$Page3.Controls.Add($LblInstallHdr)

$LblPathOverride = New-Object System.Windows.Forms.Label
$LblPathOverride.Location = New-Object System.Drawing.Point(0, 25)
$LblPathOverride.Size = New-Object System.Drawing.Size(432, 16)
$LblPathOverride.Font = $FontMonoSm
$LblPathOverride.ForeColor = [System.Drawing.Color]::FromArgb(150, 0, 40)
$LblPathOverride.UseMnemonic = $false
$LblPathOverride.Text = "Target: C:\Games\Artsy_2000"
$Page3.Controls.Add($LblPathOverride)

# Recessed 90s Animation Viewport (432 x 148 Fixed3D -> exact 428 x 144 interior, zero flicker!)
$AnimW = 428
$AnimH = 144
$PicAnim = New-Object System.Windows.Forms.PictureBox
$PicAnim.Location = New-Object System.Drawing.Point(0, 44)
$PicAnim.Size = New-Object System.Drawing.Size(432, 148)
$PicAnim.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$Page3.Controls.Add($PicAnim)
$AnimBmp = New-Object System.Drawing.Bitmap($AnimW, $AnimH)

# Live Phase & Fake File Readout
$LblPhase = New-Object System.Windows.Forms.Label
$LblPhase.Location = New-Object System.Drawing.Point(0, 197)
$LblPhase.Size = New-Object System.Drawing.Size(432, 18)
$LblPhase.Font = $FontUiBold
$LblPhase.ForeColor = $ColNavy
$LblPhase.UseMnemonic = $false
$LblPhase.Text = "Phase 1/4: Preparing hard disk..."
$Page3.Controls.Add($LblPhase)

$LblCurrFile = New-Object System.Windows.Forms.Label
$LblCurrFile.Location = New-Object System.Drawing.Point(0, 216)
$LblCurrFile.Size = New-Object System.Drawing.Size(432, 16)
$LblCurrFile.Font = New-Object System.Drawing.Font("Courier New", 7.5, [System.Drawing.FontStyle]::Regular)
$LblCurrFile.ForeColor = $ColDarkTxt
$LblCurrFile.UseMnemonic = $false
$LblCurrFile.Text = "Initializing Drive A:\ magnetic flux..."
$Page3.Controls.Add($LblCurrFile)

# Custom Authentic Segmented Win95 Progress Bar (432 x 26 Fixed3D -> exact 428 x 22 interior)
$ProgW = 428
$ProgH = 22
$PicProg = New-Object System.Windows.Forms.PictureBox
$PicProg.Location = New-Object System.Drawing.Point(0, 236)
$PicProg.Size = New-Object System.Drawing.Size(432, 26)
$PicProg.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$Page3.Controls.Add($PicProg)
$ProgBmp = New-Object System.Drawing.Bitmap($ProgW, $ProgH)

$LblTimeEst = New-Object System.Windows.Forms.Label
$LblTimeEst.Location = New-Object System.Drawing.Point(0, 266)
$LblTimeEst.Size = New-Object System.Drawing.Size(242, 16)
$LblTimeEst.Font = New-Object System.Drawing.Font("Courier New", 7.4, [System.Drawing.FontStyle]::Regular)
$LblTimeEst.UseMnemonic = $false
$LblTimeEst.Text = "Est. Time Remaining: 5 min 00 sec"
$Page3.Controls.Add($LblTimeEst)

$LblTurboStats = New-Object System.Windows.Forms.Label
$LblTurboStats.Location = New-Object System.Drawing.Point(244, 266)
$LblTurboStats.Size = New-Object System.Drawing.Size(188, 16)
$LblTurboStats.Font = $FontMonoSm
$LblTurboStats.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$LblTurboStats.ForeColor = [System.Drawing.Color]::FromArgb(0, 96, 0)
$LblTurboStats.Text = "CPU: 66 MHz | Boosts: 0"
$Page3.Controls.Add($LblTurboStats)

# Mashable Classic PC Case TURBO Speed-Up Button + LED + Mute checkbox!
$BtnTurbo = New-Object System.Windows.Forms.Button
$BtnTurbo.Location = New-Object System.Drawing.Point(0, 288)
$BtnTurbo.Size = New-Object System.Drawing.Size(266, 48)
$BtnTurbo.Font = New-Object System.Drawing.Font("MS Sans Serif", 9.8, [System.Drawing.FontStyle]::Bold)
$BtnTurbo.BackColor = [System.Drawing.Color]::FromArgb(228, 212, 140)
$BtnTurbo.Text = ">>>  SPEED UP!  <<<"
$Page3.Controls.Add($BtnTurbo)

$LblTurboLed = New-Object System.Windows.Forms.Label
$LblTurboLed.Location = New-Object System.Drawing.Point(274, 290)
$LblTurboLed.Size = New-Object System.Drawing.Size(158, 20)
$LblTurboLed.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$LblTurboLed.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 24)
$LblTurboLed.ForeColor = [System.Drawing.Color]::FromArgb(80, 140, 80)
$LblTurboLed.Font = $FontMonoSm
$LblTurboLed.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$LblTurboLed.Text = "TURBO LED: STANDBY"
$Page3.Controls.Add($LblTurboLed)

$ChkMute = New-Object System.Windows.Forms.CheckBox
$ChkMute.Location = New-Object System.Drawing.Point(276, 314)
$ChkMute.Size = New-Object System.Drawing.Size(156, 20)
$ChkMute.Font = $FontSmall
$ChkMute.Text = "Mute PC Speaker Beeps"
$ChkMute.Add_CheckedChanged({ $script:MuteBeeps = $ChkMute.Checked })
$Page3.Controls.Add($ChkMute)

# ==============================================================================
# PAGE 4: CORRUPTED FREE DISK RESOLUTION - CHEEKY BUCK-FIFTY QUIP + STEAM BUTTON
# ==============================================================================
$Page4 = New-PagePanel "full"

$LblDoneTitle = New-Object System.Windows.Forms.Label
$LblDoneTitle.Location = New-Object System.Drawing.Point(16, 0)
$LblDoneTitle.Size = New-Object System.Drawing.Size(744, 22)
$LblDoneTitle.Font = $FontTitle
$LblDoneTitle.ForeColor = [System.Drawing.Color]::FromArgb(165, 0, 24)
$LblDoneTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$LblDoneTitle.Text = "Setup Failed at 99.4% — Corrupted Ad-Supported Free Disk Image!"
$Page4.Controls.Add($LblDoneTitle)

$LblDoneBody = New-Object System.Windows.Forms.Label
$LblDoneBody.Location = New-Object System.Drawing.Point(18, 24)
$LblDoneBody.Size = New-Object System.Drawing.Size(740, 30)
$LblDoneBody.TextAlign = [System.Drawing.ContentAlignment]::TopCenter
$LblDoneBody.Text = "Relax, Subject 13 — no files on your PC were harmed, shredded, or defragmented! Sadly, 30 years of Sub-Level 4 magnetic decay`r`ncorrupted A:\DATA\GAME.DAT in this free ad-supported installer — so grab the clean, ad-free full release on S.T.E.A.M.:"
$Page4.Controls.Add($LblDoneBody)

# Cheeky / jerky Buck-Fifty callout bar right above the Steam Store button!
$LblQuip = New-Object System.Windows.Forms.Label
$LblQuip.Location = New-Object System.Drawing.Point(108, 56)
$LblQuip.Size = New-Object System.Drawing.Size(560, 24)
$LblQuip.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$LblQuip.BackColor = [System.Drawing.Color]::FromArgb(18, 28, 72)
$LblQuip.ForeColor = [System.Drawing.Color]::FromArgb(255, 232, 92)
$LblQuip.Font = New-Object System.Drawing.Font("MS Sans Serif", 8.8, [System.Drawing.FontStyle]::Bold)
$LblQuip.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$LblQuip.Text = '"Hey buddy — it''s only a buck fifty anyways, am I right?"  (wink wink, nod nod)'
$Page4.Controls.Add($LblQuip)

# Helper to open Steam Store page with retro chime
$OpenSteamStoreAction = {
    Invoke-RetroBeep 880 65
    Invoke-RetroBeep 1175 95
    $LblStoreStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 110, 0)
    $LblStoreStatus.Text = "Launching Artsy_2000 on Steam ($SteamStoreUrl)..."
    try {
        Start-Process $SteamStoreUrl
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Please visit: $SteamStoreUrl",
            "Artsy_2000 on Steam",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
}

# Giant clickable retro Win95 artwork button featuring Box Art + Ancient S.T.E.A.M. Emblem! (Centered 560 x 192)
$script:SteamBtnHover = $false
$script:SteamBtnDown  = $false

$PicSteamBtn = New-Object System.Windows.Forms.PictureBox
$PicSteamBtn.Location = New-Object System.Drawing.Point(108, 84)
$PicSteamBtn.Size = New-Object System.Drawing.Size(560, 192)
$PicSteamBtn.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
$PicSteamBtn.Cursor = [System.Windows.Forms.Cursors]::Hand
if ($ImgSteamBtn) { $PicSteamBtn.Image = $ImgSteamBtn }

$ToolTip = New-Object System.Windows.Forms.ToolTip
$ToolTip.SetToolTip($PicSteamBtn, "Click to open Artsy_2000 on Steam ($SteamStoreUrl)")

$PicSteamBtn.Add_MouseEnter({
    $script:SteamBtnHover = $true
    $PicSteamBtn.Invalidate()
})
$PicSteamBtn.Add_MouseLeave({
    $script:SteamBtnHover = $false
    $script:SteamBtnDown  = $false
    $PicSteamBtn.Invalidate()
})
$PicSteamBtn.Add_MouseDown({
    $script:SteamBtnDown = $true
    $PicSteamBtn.Invalidate()
})
$PicSteamBtn.Add_MouseUp({
    $script:SteamBtnDown = $false
    $PicSteamBtn.Invalidate()
})
$PicSteamBtn.Add_Click($OpenSteamStoreAction)
$PicSteamBtn.Add_Paint({
    param($sender, $e)
    $w = $sender.Width; $h = $sender.Height
    if ($script:SteamBtnDown) {
        $pDark = New-Object System.Drawing.Pen([System.Drawing.Color]::Black, 3)
        $pLite = New-Object System.Drawing.Pen([System.Drawing.Color]::White, 2)
        $e.Graphics.DrawLine($pDark, 0, 0, $w - 1, 0)
        $e.Graphics.DrawLine($pDark, 0, 0, 0, $h - 1)
        $e.Graphics.DrawLine($pLite, 0, $h - 1, $w - 1, $h - 1)
        $e.Graphics.DrawLine($pLite, $w - 1, 0, $w - 1, $h - 1)
        $pDark.Dispose(); $pLite.Dispose()
    } elseif ($script:SteamBtnHover) {
        $pGlow = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 232, 82), 3)
        $e.Graphics.DrawRectangle($pGlow, 1, 1, $w - 3, $h - 3)
        $pGlow.Dispose()
    }
})
$Page4.Controls.Add($PicSteamBtn)

# Clickable classic blue underlined hyperlink directly beneath the artwork button
$LnkSteamUrl = New-Object System.Windows.Forms.LinkLabel
$LnkSteamUrl.Location = New-Object System.Drawing.Point(108, 279)
$LnkSteamUrl.Size = New-Object System.Drawing.Size(560, 17)
$LnkSteamUrl.Font = $FontMonoB
$LnkSteamUrl.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$LnkSteamUrl.LinkColor = [System.Drawing.Color]::FromArgb(0, 0, 180)
$LnkSteamUrl.ActiveLinkColor = [System.Drawing.Color]::FromArgb(180, 0, 120)
$LnkSteamUrl.Text = $SteamStoreUrl
$LnkSteamUrl.Add_LinkClicked($OpenSteamStoreAction)
$Page4.Controls.Add($LnkSteamUrl)

$LblStoreStatus = New-Object System.Windows.Forms.Label
$LblStoreStatus.Location = New-Object System.Drawing.Point(108, 297)
$LblStoreStatus.Size = New-Object System.Drawing.Size(560, 14)
$LblStoreStatus.Font = $FontSmall
$LblStoreStatus.ForeColor = $ColMuted
$LblStoreStatus.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$LblStoreStatus.Text = "Click the banner or link above to open the official Artsy_2000 Steam Store page."
$Page4.Controls.Add($LblStoreStatus)

$BtnOpenSteam = New-Object System.Windows.Forms.Button
$BtnOpenSteam.Location = New-Object System.Drawing.Point(174, 314)
$BtnOpenSteam.Size = New-Object System.Drawing.Size(210, 26)
$BtnOpenSteam.Font = $FontUiBold
$BtnOpenSteam.BackColor = [System.Drawing.Color]::FromArgb(228, 212, 140)
$BtnOpenSteam.Text = "Open Steam Store Page"
$BtnOpenSteam.Add_Click($OpenSteamStoreAction)
$Page4.Controls.Add($BtnOpenSteam)

$BtnOpenWeb = New-Object System.Windows.Forms.Button
$BtnOpenWeb.Location = New-Object System.Drawing.Point(394, 314)
$BtnOpenWeb.Size = New-Object System.Drawing.Size(210, 26)
$BtnOpenWeb.Font = $FontUiBold
$BtnOpenWeb.Text = "Visit BUCKFIFTYLABS.COM"
$BtnOpenWeb.Add_Click({
    Start-Process "https://buckfiftylabs.com"
})
$Page4.Controls.Add($BtnOpenWeb)

# ==============================================================================
# STATE MACHINE, CYCLING BUCK-FIFTY ADS, RETRO ANIMATIONS & 5-MIN PROGRESS TIMER
# ==============================================================================
$script:CurrentPage = 0
$script:Progress = 0.0
$script:AnimTick = 0
$script:TurboClicks = 0
$script:TurboFlash = 0
$script:AdIndex = 0
$script:AdTicks = 0
$script:DeletePrompted = $false
$script:InstallFinished = $false

function Advance-SponsorAd {
    if ($AdImages.Count -eq 0) { return }
    $script:AdIndex = ($script:AdIndex + 1) % $AdImages.Count
    $script:AdTicks = 0
    $PicAdSidebar.Image = $AdImages[$script:AdIndex]
    $PicAdSidebar.Invalidate()
}

$PicAdSidebar.Add_Click({
    Advance-SponsorAd
    Invoke-RetroBeep 740 25
})

# Deterministic pseudo-random cluster map for authentic Win95 DEFRAG.EXE animation (20 x 6 = 120 blocks)
$script:DefragInit = New-Object int[] 120
$rng = New-Object System.Random(1996)
for ($k = 0; $k -lt 120; $k++) {
    $v = $rng.Next(100)
    if ($v -lt 32) { $script:DefragInit[$k] = 2 }      # Red = Fragmented
    elseif ($v -lt 68) { $script:DefragInit[$k] = 1 }  # Cyan = Used data
    else { $script:DefragInit[$k] = 0 }                # White = Free space
}

$FakeDeleteFiles = @(
    "Shredding: C:\MYDOCU~1\TAXES_1996.DOC (420 KB)",
    "Evicting:  C:\WINDOWS\SOL.EXE (Low Productivity)",
    "Purging:   C:\WINDOWS\WINMINE.EXE (Unauth. Fun)",
    "Deleting:  C:\PHOTOS\SUMMER_95.BMP (1.12 MB)",
    "Removing:  C:\MYDOCU~1\NOVEL_DRAFT_FINAL_V9.WRI",
    "Clearing:  C:\WINDOWS\SYSTEM32\UNUSED_STUFF.DLL",
    "Shredding: C:\DOWNLOADS\MIDI_COLLECTION.ZIP",
    "Reclaiming: 14.2 MB Contiguous Magnetic Sectors..."
)

$FakeCopyFiles = @(
    "Copying: A:\DATA\GAME.DAT -> C:\Games\Artsy_2000\",
    "Copying: A:\SPIKED.3D -> C:\Games\Artsy_2000\",
    "Copying: A:\VANCE_01.FMV -> C:\Games\Artsy_2000\",
    "Copying: A:\ISOLATE.DAT -> C:\Games\Artsy_2000\",
    "Copying: A:\THERISE.RAY -> C:\Games\Artsy_2000\",
    "Copying: A:\PIZZA_V.WAV -> C:\Games\Artsy_2000\",
    "Copying: A:\BRAIN_OP.DLL -> C:\Games\Artsy_2000\",
    "Copying: A:\POVRAY37.BAT -> C:\Games\Artsy_2000\",
    "Copying: A:\HOLON_01.MID -> C:\Games\Artsy_2000\",
    "Updating: C:\CONFIG.SYS & AUTOEXEC.BAT (No Backup)"
)

# ---- Draw Segmented Classic Win95 Progress Bar (428 x 22) ----
function Render-ProgressBar([double]$pct, [bool]$isError = $false) {
    $g = [System.Drawing.Graphics]::FromImage($ProgBmp)
    $g.Clear([System.Drawing.Color]::FromArgb(228, 228, 228))
    $maxW = $ProgW - 8
    $fillW = [int]([Math]::Min(1.0, [Math]::Max(0.0, $pct / 100.0)) * $maxW)
    $blockW = 9
    $gap = 2
    $barCol = if ($isError) { [System.Drawing.Color]::FromArgb(185, 16, 28) } else { $ColNavy }
    $bFill = New-Object System.Drawing.SolidBrush($barCol)
    for ($bx = 4; $bx + $blockW -le 4 + $fillW; $bx += ($blockW + $gap)) {
        $g.FillRectangle($bFill, $bx, 3, $blockW, $ProgH - 6)
    }
    $txt = if ($isError) { "{0:N1}%  —  DISK READ ERROR! (SECTOR #0419)" -f $pct } else { "{0:N1}%" -f $pct }
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $bShadow = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Black)
    $bFg = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Yellow)
    $g.DrawString($txt, $FontUiBold, $bShadow, ($ProgW / 2 + 1), ($ProgH / 2 + 1), $sf)
    $g.DrawString($txt, $FontUiBold, $bFg, ($ProgW / 2), ($ProgH / 2), $sf)
    $bFill.Dispose(); $bShadow.Dispose(); $bFg.Dispose(); $sf.Dispose(); $g.Dispose()
    $PicProg.Image = $ProgBmp
    $PicProg.Invalidate()
}

# ---- Draw Hilarious Ancient Win95 Icon Animations per Phase (428 x 144) ----
function Render-InstallAnimation([double]$pct, [int]$tick, [bool]$isError = $false) {
    $g = [System.Drawing.Graphics]::FromImage($AnimBmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::None

    # Classic dark teal Win95 desktop / technical viewport canvas
    $g.Clear([System.Drawing.Color]::FromArgb(0, 88, 92))
    $pGrid = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 106, 110))
    for ($gx = 0; $gx -lt $AnimW; $gx += 22) { $g.DrawLine($pGrid, $gx, 0, $gx, $AnimH) }
    for ($gy = 0; $gy -lt $AnimH; $gy += 22) { $g.DrawLine($pGrid, 0, $gy, $AnimW, $gy) }
    $pGrid.Dispose()

    $pBlk   = New-Object System.Drawing.Pen([System.Drawing.Color]::Black, 1)
    $pWht   = New-Object System.Drawing.Pen([System.Drawing.Color]::White, 1)
    $bGray  = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(196, 196, 188))
    $bDGray = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(110, 110, 108))
    $bYel   = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 220, 88))
    $bWht   = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $bRed   = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(230, 50, 50))
    $bOrg   = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 165, 30))
    $bBlue  = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(30, 80, 200))
    $bCyan  = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(56, 232, 255))
    $bGrn   = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(60, 240, 100))

    $fAnimHdr = New-Object System.Drawing.Font("Courier New", 7.3, [System.Drawing.FontStyle]::Bold)
    $fAnimSub = New-Object System.Drawing.Font("Courier New", 7.0, [System.Drawing.FontStyle]::Regular)

    if ($isError) {
        # ---- FATAL FAILURE FRAME: CORRUPTED 3.5" FLOPPY DISKETTE + CRC STATIC! ----
        $g.Clear([System.Drawing.Color]::FromArgb(46, 6, 12))
        $pErr = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(145, 22, 34), 1)
        for ($gy = 0; $gy -lt $AnimH; $gy += 6) { $g.DrawLine($pErr, 0, $gy, $AnimW, $gy) }
        $pErr.Dispose()

        # Left: Cracked / Sparking 3.5" Floppy Diskette Icon
        $g.FillRectangle($bBlue, 18, 32, 62, 68)
        $g.DrawRectangle($pBlk, 18, 32, 62, 68)
        $g.FillRectangle($bGray, 32, 32, 34, 24)
        $g.DrawRectangle($pBlk, 32, 32, 34, 24)
        $g.FillRectangle($bWht, 26, 64, 46, 30)
        $g.DrawRectangle($pBlk, 26, 64, 46, 30)
        $pCrack = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 60, 60), 3)
        $g.DrawLine($pCrack, 22, 40, 44, 62)
        $g.DrawLine($pCrack, 44, 62, 38, 76)
        $g.DrawLine($pCrack, 38, 76, 74, 96)
        $pCrack.Dispose()
        $g.FillRectangle($bYel, 68, 26, 7, 7)
        $g.FillRectangle($bOrg, 78, 38, 5, 5)
        $g.FillRectangle($bRed, 12, 74, 7, 7)
        $g.DrawString("A:\ CORRUPT", $fAnimHdr, $bYel, 12, 108)

        # Right: Classic 1996 DOS/Win95 Fatal Readout Box
        $g.FillRectangle($bRed, 96, 16, 322, 22)
        $g.DrawRectangle($pWht, 96, 16, 322, 22)
        $g.DrawString("!! CRITICAL DISK ERROR 0x1996-B50 !!", $fAnimHdr, $bYel, 108, 21)
        $g.DrawString("FILE  : A:\DATA\GAME.DAT (CRC FAIL 99.4%)", $fAnimHdr, $bWht, 98, 48)
        $g.DrawString("SECTOR: TRACK 79 / HEAD 1 / SECTOR #0419", $fAnimSub, $bCyan, 98, 66)
        $g.DrawString("CAUSE : 30-YR SUB-LEVEL 4 MAGNETIC DECAY", $fAnimSub, $bYel, 98, 84)
        $g.DrawString("ACTION: ABORTING -> ENGAGING S.T.E.A.M.", $fAnimHdr, $bGrn, 98, 108)

    } elseif ($pct -lt 24.0) {
        # ---- PHASE 1: FREEING UP HARD DRIVE SPACE (FLYING DOCS INTO FLAMING RECYCLE BIN!) ----
        $g.FillRectangle($bGray, 18, 46, 72, 52)
        $g.DrawRectangle($pBlk, 18, 46, 72, 52)
        $g.DrawLine($pWht, 19, 47, 89, 47)
        $g.FillRectangle($bDGray, 26, 56, 56, 12)
        $ledBrush = if (($tick % 4) -lt 2) { $bRed } else { $bGrn }
        $g.FillRectangle($ledBrush, 74, 82, 10, 6)
        $g.DrawString("C:\ DRIVE", $fAnimHdr, $bWht, 20, 106)

        $shk = if (($tick % 2) -eq 0) { -2 } else { 2 }
        $tx = 342 + $shk
        $flH = 12 + (($tick * 5) % 10)
        $g.FillEllipse($bRed, $tx + 4, 34 - $flH, 22, 22)
        $g.FillEllipse($bOrg, $tx + 20, 28 - ($flH / 2), 24, 24)
        $g.FillEllipse($bYel, $tx + 14, 38 - ($flH / 3), 20, 20)
        $g.FillRectangle($bGray, $tx, 50, 52, 52)
        $g.DrawRectangle($pBlk, $tx, 50, 52, 52)
        $g.FillRectangle($bDGray, $tx - 4, 44, 60, 8)
        $g.DrawRectangle($pBlk, $tx - 4, 44, 60, 8)
        for ($rx = $tx + 9; $rx -le $tx + 42; $rx += 11) {
            $g.DrawLine($pBlk, $rx, 56, $rx, 96)
        }
        $g.DrawString("SHREDDER", $fAnimHdr, $bYel, 338, 108)

        for ($f = 0; $f -lt 3; $f++) {
            $u = (($tick * 0.065) + ($f * 0.333)) % 1.0
            $fx = [int](96 + $u * 234)
            $fy = [int](64 - [Math]::Sin($u * [Math]::PI) * 38)
            if (($f % 2) -eq 0) {
                $g.FillRectangle($bYel, $fx, $fy - 4, 13, 5)
                $g.FillRectangle($bYel, $fx, $fy, 26, 20)
                $g.DrawRectangle($pBlk, $fx, $fy, 26, 20)
            } else {
                $g.FillRectangle($bWht, $fx, $fy, 20, 24)
                $g.DrawRectangle($pBlk, $fx, $fy, 20, 24)
                $g.DrawLine($pBlk, $fx + 4, $fy + 6, $fx + 16, $fy + 6)
                $g.DrawLine($pBlk, $fx + 4, $fy + 11, $fx + 14, $fy + 11)
                $g.DrawLine($pBlk, $fx + 4, $fy + 16, $fx + 16, $fy + 16)
            }
        }
        $g.DrawString("FREEING DISK SPACE: REMOVING DOCS & SOLITAIRE...", $fAnimHdr, $bYel, 10, 8)

    } elseif ($pct -lt 52.0) {
        # ---- PHASE 2: AUTHENTIC WINDOWS 95 DEFRAG.EXE CLUSTER BLOCK MAP (20 x 6 = 120 blocks)! ----
        $g.Clear([System.Drawing.Color]::FromArgb(192, 192, 192))
        $g.DrawString("MS-DEFRAG 95 - Optimizing C:\ Clusters (Don't Breathe)", $FontUiBold, $bBlue, 8, 5)
        $cols = 20; $rows = 6; $cellW = 18; $cellH = 14; $ox = 14; $oy = 26
        $defragRatio = ($pct - 24.0) / 28.0
        $optCount = [int]($defragRatio * 120)
        $readIdx  = ($optCount + ($tick % 17) + 3) % 120
        $writeIdx = [Math]::Min(119, $optCount)

        for ($idx = 0; $idx -lt 120; $idx++) {
            $r = [int][Math]::Floor($idx / $cols)
            $c = $idx % $cols
            $bx = $ox + $c * ($cellW + 2)
            $by = $oy + $r * ($cellH + 2)
            if ($idx -eq $writeIdx) {
                $br = $bYel
            } elseif ($idx -eq $readIdx) {
                $br = $bGrn
            } elseif ($idx -lt $optCount) {
                $br = if ($idx -lt 82) { $bBlue } else { $bWht }
            } else {
                $st = $script:DefragInit[$idx]
                $br = if ($st -eq 2) { $bRed } elseif ($st -eq 1) { $bCyan } else { $bWht }
            }
            $g.FillRectangle($br, $bx, $by, $cellW, $cellH)
            $g.DrawRectangle($pBlk, $bx, $by, $cellW, $cellH)
        }
        $ly = 126
        $g.FillRectangle($bBlue, 14, $ly, 10, 9);  $g.DrawRectangle($pBlk, 14, $ly, 10, 9)
        $g.DrawString("Opt.", $FontSmall, $bDGray, 27, $ly - 2)
        $g.FillRectangle($bRed, 68, $ly, 10, 9);   $g.DrawRectangle($pBlk, 68, $ly, 10, 9)
        $g.DrawString("Frag.", $FontSmall, $bDGray, 81, $ly - 2)
        $g.FillRectangle($bGrn, 130, $ly, 10, 9);  $g.DrawRectangle($pBlk, 130, $ly, 10, 9)
        $g.DrawString("Read", $FontSmall, $bDGray, 143, $ly - 2)
        $g.FillRectangle($bYel, 192, $ly, 10, 9);  $g.DrawRectangle($pBlk, 192, $ly, 10, 9)
        $g.DrawString("Write", $FontSmall, $bDGray, 205, $ly - 2)
        $g.FillRectangle($bWht, 256, $ly, 10, 9);  $g.DrawRectangle($pBlk, 256, $ly, 10, 9)
        $g.DrawString("Free Sector", $FontSmall, $bDGray, 269, $ly - 2)

    } elseif ($pct -lt 86.0) {
        # ---- PHASE 3: CLASSIC WIN95 FLYING FLOPPY TO C:\Games\Artsy_2000 FOLDER! ----
        $g.FillRectangle($bBlue, 22, 36, 60, 64)
        $g.DrawRectangle($pBlk, 22, 36, 60, 64)
        $g.FillRectangle($bGray, 35, 36, 32, 22)
        $g.DrawRectangle($pBlk, 35, 36, 32, 22)
        $g.FillRectangle($bBlue, 52, 40, 8, 14)
        $g.FillRectangle($bWht, 30, 66, 44, 30)
        $g.DrawRectangle($pBlk, 30, 66, 44, 30)
        $g.DrawString("A:\ FLOPPY", $fAnimHdr, $bCyan, 16, 108)

        $g.FillRectangle($bYel, 326, 42, 30, 11)
        $g.DrawRectangle($pBlk, 326, 42, 30, 11)
        $g.FillRectangle($bYel, 326, 52, 78, 48)
        $g.DrawRectangle($pBlk, 326, 52, 78, 48)
        $g.DrawString("C:\Games\Artsy_2000", $fAnimHdr, $bYel, 282, 108)

        for ($f = 0; $f -lt 3; $f++) {
            $u = (($tick * 0.07) + ($f * 0.333)) % 1.0
            $fx = [int](90 + $u * 224)
            $fy = [int](62 - [Math]::Sin($u * [Math]::PI) * 34)
            $g.FillRectangle($bWht, $fx, $fy, 22, 26)
            $g.DrawRectangle($pBlk, $fx, $fy, 22, 26)
            $g.DrawLine($pBlk, $fx + 4, $fy + 6, $fx + 18, $fy + 6)
            $g.DrawLine($pBlk, $fx + 4, $fy + 12, $fx + 16, $fy + 12)
            $g.DrawLine($pBlk, $fx + 4, $fy + 18, $fx + 18, $fy + 18)
        }
        $g.DrawString("COPYING 1.44MB SECTORS -> C:\Games\Artsy_2000...", $fAnimHdr, $bWht, 10, 8)

    } else {
        # ---- PHASE 4: SPINNING WIREFRAME SPIKED SPHERE CRT CALIBRATION! ----
        $g.Clear([System.Drawing.Color]::FromArgb(8, 14, 28))
        $pCyan = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(56, 232, 255), 1.5)
        $pMag  = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 61, 154), 1.5)
        for ($hy = 92; $hy -lt $AnimH; $hy += 10) { $g.DrawLine($pMag, 0, $hy, $AnimW, $hy) }
        $scx = 214; $scy = 66; $rad = 24
        $g.DrawEllipse($pCyan, $scx - $rad, $scy - $rad, $rad * 2, $rad * 2)
        for ($s = 0; $s -lt 12; $s++) {
            $ang = ($s * [Math]::PI * 2.0 / 12.0) + ($tick * 0.14)
            $x1 = [int]($scx + [Math]::Cos($ang) * $rad)
            $y1 = [int]($scy + [Math]::Sin($ang) * $rad)
            $x2 = [int]($scx + [Math]::Cos($ang) * ($rad + 20))
            $y2 = [int]($scy + [Math]::Sin($ang) * ($rad + 20))
            $g.DrawLine($pMag, $x1, $y1, $x2, $y2)
        }
        $g.DrawString("VERIFYING A:\DATA\GAME.DAT & CRT CALIBRATION...", $fAnimHdr, $bGrn, 10, 8)
        $g.DrawString("0% GPU DETECTED - CHECKING MAGNETIC INTEGRITY...", $fAnimHdr, $bYel, 10, 122)
        $pCyan.Dispose(); $pMag.Dispose()
    }

    $fAnimHdr.Dispose(); $fAnimSub.Dispose()
    $pBlk.Dispose(); $pWht.Dispose(); $bGray.Dispose(); $bDGray.Dispose(); $bYel.Dispose()
    $bWht.Dispose(); $bRed.Dispose(); $bOrg.Dispose(); $bBlue.Dispose(); $bCyan.Dispose(); $bGrn.Dispose()
    $g.Dispose()
    $PicAnim.Image = $AnimBmp
    $PicAnim.Invalidate()
}

# ---- Trigger Dramatic 99.4% Corrupted Floppy Disk Failure -> Emergency Steam Key Screen! ----
function Invoke-InstallFailure {
    if ($script:InstallFinished) { return }
    $script:InstallFinished = $true
    $script:Progress = 99.4
    $InstallTimer.Stop()

    $BtnTurbo.Enabled = $false
    $BtnTurbo.BackColor = [System.Drawing.Color]::FromArgb(180, 140, 140)
    $BtnTurbo.Text = "!! DRIVE A:\ READ FAILURE !!"
    $LblTurboLed.BackColor = [System.Drawing.Color]::FromArgb(190, 20, 28)
    $LblTurboLed.ForeColor = [System.Drawing.Color]::Yellow
    $LblTurboLed.Text = "DISK ERR: 0xB50"
    $LblPhase.ForeColor = [System.Drawing.Color]::FromArgb(165, 0, 24)
    $LblPhase.Text = "FATAL ERROR: CRC Failure reading A:\DATA\GAME.DAT!"
    $LblCurrFile.Text = 'Sector #0419 (Track 79, Head 1) — Magnetic Flux Decay!'
    $LblTimeEst.Text = "Est. Time Remaining: FAILED"

    Render-ProgressBar 99.4 $true
    Render-InstallAnimation 99.4 $script:AnimTick $true
    $Form.Refresh()
    [System.Windows.Forms.Application]::DoEvents()

    # Sad descending 1996 PC Speaker error tones!
    Invoke-RetroBeep 392 95
    Invoke-RetroBeep 311 95
    Invoke-RetroBeep 233 110
    Invoke-RetroBeep 147 220

    [System.Windows.Forms.MessageBox]::Show(
        "ABORT, RETRY, FAIL?`r`n`r`n" +
        "CRITICAL DISK READ ERROR verifying A:\DATA\GAME.DAT`r`n" +
        "(Track 79, Head 1, Sector #0419 — 99.4% Complete).`r`n`r`n" +
        "DIAGNOSIS:`r`n" +
        "After 30 years in a Sub-Level 4 filing cabinet, the magnetic iron-oxide`r`n" +
        "coating on this 3.5`" floppy diskette has catastrophically decayed.`r`n" +
        "Installation to C:\Games\Artsy_2000 has FAILED!`r`n`r`n" +
        "(Don't worry: zero files on your PC were actually deleted or defragmented.)`r`n`r`n" +
        "Click OK to grab an uncorrupted copy of Artsy_2000 on S.T.E.A.M. (Steam)...",
        "CRITICAL DISK READ ERROR — DRIVE A:\ (ERROR 0xB50)",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null

    Show-WizardPage 4
}

# ---- Installation Timer: 100ms ticks -> natural rate 0.03333%/tick = exact 5 minutes (300 seconds)! ----
$InstallTimer = New-Object System.Windows.Forms.Timer
$InstallTimer.Interval = 100

$InstallTimer.Add_Tick({
    $script:AnimTick++
    $script:AdTicks++

    # Rotate Buck-Fifty sponsor ad automatically every 3.2 seconds!
    if ($script:AdTicks -ge 32) {
        Advance-SponsorAd
    }

    # Fire the unstoppable "Freeing Up Hard Drive Space" confirmation dialog right after install begins!
    if (-not $script:DeletePrompted -and $script:AnimTick -ge 4) {
        $script:DeletePrompted = $true
        $InstallTimer.Stop()
        Invoke-RetroBeep 440 120
        $res = [System.Windows.Forms.MessageBox]::Show(
            "WARNING: INSUFFICIENT CONTIGUOUS SECTORS ON DRIVE C:\!`r`n`r`n" +
            "To install Artsy_2000 into C:\Games\Artsy_2000, Setup must free 14.2 MB by permanently removing:`r`n" +
            "  * Existing Applications (Solitaire, Minesweeper, Tax Software)`r`n" +
            "  * Personal Documents, Photos & Unfinished Novels`r`n" +
            "  * Assorted Windows Files You Probably Don't Need`r`n`r`n" +
            "Do you authorize Buck-Fifty Innovation Labs to delete these files now?",
            "Buck-Fifty Disk Space Reclamation",
            [System.Windows.Forms.MessageBoxButtons]::YesNoCancel,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($res -eq [System.Windows.Forms.DialogResult]::Yes) {
            [System.Windows.Forms.MessageBox]::Show(
                "Thank you for your enthusiastic compliance, Subject 13!`r`nShredding personal documents and Solitaire high scores now...",
                "Compliance Verified",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        } else {
            [System.Windows.Forms.MessageBox]::Show(
                "Denial logged in your permanent Sub-Level 4 HR dossier.`r`nProceeding anyway under Executive Override Protocol #19-B!",
                "Executive Override Engaged",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Exclamation
            ) | Out-Null
        }
        $InstallTimer.Start()
        return
    }

    # Painfully slow 5-minute natural advance (100% / 3000 ticks = 0.033333% per 100ms tick)
    $script:Progress += (100.0 / 3000.0)
    if ($script:Progress -ge 99.4) {
        Invoke-InstallFailure
        return
    }

    # Update phase & fake operation text
    if ($script:Progress -lt 24.0) {
        $LblPhase.Text = "Phase 1/4: Freeing up hard drive space (removing apps & docs)..."
        $fi = [int]([Math]::Floor($script:AnimTick / 6)) % $FakeDeleteFiles.Count
        $LblCurrFile.Text = $FakeDeleteFiles[$fi]
    } elseif ($script:Progress -lt 52.0) {
        $LblPhase.Text = "Phase 2/4: Defragmenting C:\ magnetic clusters (MS-DEFRAG 95)..."
        $cluster = [int](($script:Progress - 24.0) / 28.0 * 65535)
        $LblCurrFile.Text = "Relocating Sector #$cluster -> C:\Games\Artsy_2000"
    } elseif ($script:Progress -lt 86.0) {
        $LblPhase.Text = "Phase 3/4: Copying compressed 1.44MB files to C:\Games\Artsy_2000..."
        $ci = [int]([Math]::Floor($script:AnimTick / 5)) % $FakeCopyFiles.Count
        $LblCurrFile.Text = $FakeCopyFiles[$ci]
    } else {
        $LblPhase.Text = 'Phase 4/4: Verifying A:\DATA\GAME.DAT CRC & 14" CRT...'
        $LblCurrFile.Text = "Checking Track 79, Sector #0419 (0% GPU compliance)..."
    }

    # Remaining time at painfully slow natural speed
    $remSec = [int][Math]::Ceiling((100.0 - $script:Progress) * 3.0)
    $mins = [int][Math]::Floor($remSec / 60)
    $secs = $remSec % 60
    $LblTimeEst.Text = ("Est. Time Remaining: {0} min {1:D2} sec" -f $mins, $secs)

    # Turbo LED fade
    if ($script:TurboFlash -gt 0) {
        $script:TurboFlash--
        $LblTurboLed.BackColor = [System.Drawing.Color]::FromArgb(255, 196, 0)
        $LblTurboLed.ForeColor = [System.Drawing.Color]::Black
        $LblTurboLed.Text = "TURBO LED: OVERDRIVE!"
    } else {
        $LblTurboLed.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 24)
        $LblTurboLed.ForeColor = [System.Drawing.Color]::FromArgb(80, 160, 80)
        $LblTurboLed.Text = "TURBO LED: STANDBY"
    }

    Render-ProgressBar $script:Progress
    Render-InstallAnimation $script:Progress $script:AnimTick
})

# ---- Mashable SPEED UP Button: +4.5% chunk per click (also cycles sponsor ads every 3 clicks!) ----
$BtnTurbo.Add_Click({
    if ($script:InstallFinished) { return }
    $script:TurboClicks++
    $script:TurboFlash = 3
    if (($script:TurboClicks % 3) -eq 0) {
        Advance-SponsorAd
    }
    $script:Progress = [Math]::Min(99.4, $script:Progress + 4.5)
    $mhz = 66 + $script:TurboClicks * 33
    $LblTurboStats.Text = ("CPU: {0} MHz | Boosts: {1}" -f $mhz, $script:TurboClicks)
    Invoke-RetroBeep (600 + [Math]::Min(900, $script:TurboClicks * 35)) 25
    if ($script:Progress -ge 99.4) {
        Invoke-InstallFailure
        return
    }
    Render-ProgressBar $script:Progress
    Render-InstallAnimation $script:Progress $script:AnimTick
})

# ---- Wizard Navigation Controller ----
$Pages = @($Page0, $Page1, $Page2, $Page3, $Page4)

function Show-WizardPage([int]$idx) {
    $script:CurrentPage = $idx
    for ($i = 0; $i -lt $Pages.Count; $i++) {
        $Pages[$i].Visible = ($i -eq $idx)
    }
    # Left Artsy sidebar stays visible on steps 0..3; Right cycling Buck-Fifty Ads appear on step 3 (Install)!
    $PicSidebar.Visible   = ($idx -le 3)
    $PicAdSidebar.Visible = ($idx -eq 3 -and $AdImages.Count -gt 0)

    switch ($idx) {
        0 {
            $BtnBack.Enabled = $false
            $BtnNext.Enabled = $true
            $BtnNext.Text = "&Next >"
            $BtnCancel.Enabled = $true
            $BtnCancel.Text = "Cancel"
        }
        1 {
            $BtnBack.Enabled = $true
            $BtnNext.Enabled = $true
            $BtnNext.Text = "&Next >"
            $BtnCancel.Enabled = $true
            $BtnCancel.Text = "Cancel"
        }
        2 {
            $BtnBack.Enabled = $true
            $BtnNext.Enabled = $true
            $BtnNext.Text = "&Install Now!"
            $BtnCancel.Enabled = $true
            $BtnCancel.Text = "Cancel"
        }
        3 {
            $BtnBack.Enabled = $false
            $BtnNext.Enabled = $false
            $BtnNext.Text = "Installing..."
            $BtnCancel.Enabled = $true
            $BtnCancel.Text = "Abort"

            # Always force C:\Games\Artsy_2000 regardless of what user typed in Page 1!
            $chosen = $TxtPath.Text.Trim()
            if ($chosen -ieq "C:\Games\Artsy_2000" -or [string]::IsNullOrWhiteSpace($chosen)) {
                $LblPathOverride.Text = "Target: C:\Games\Artsy_2000 (Sub-Level 4 Standard)"
            } else {
                $shortCh = if ($chosen.Length -gt 20) { $chosen.Substring(0, 17) + "..." } else { $chosen }
                $LblPathOverride.Text = "Target: C:\Games\Artsy_2000 (Ignored '$shortCh'!)"
            }
            $script:Progress = 0.0
            $script:AnimTick = 0
            $script:TurboClicks = 0
            $script:AdIndex = 0
            $script:AdTicks = 0
            $script:DeletePrompted = $false
            $script:InstallFinished = $false
            if ($AdImages.Count -gt 0) { $PicAdSidebar.Image = $AdImages[0] }
            Render-ProgressBar 0.0
            Render-InstallAnimation 0.0 0
            $BtnTurbo.Focus()
            $InstallTimer.Start()
        }
        4 {
            $BtnBack.Enabled = $false
            $BtnNext.Enabled = $true
            $BtnNext.Text = "&Finish"
            $BtnCancel.Enabled = $false
            $BtnCancel.Text = "Close"
            $BtnOpenSteam.Focus()
        }
    }
}

$BtnBack.Add_Click({
    if ($script:CurrentPage -gt 0 -and $script:CurrentPage -le 2) {
        Show-WizardPage ($script:CurrentPage - 1)
    }
})

$BtnNext.Add_Click({
    if ($script:CurrentPage -lt 3) {
        Show-WizardPage ($script:CurrentPage + 1)
    } elseif ($script:CurrentPage -eq 4) {
        $Form.Close()
    }
})

$BtnCancel.Add_Click({
    if ($script:CurrentPage -eq 3 -and -not $script:InstallFinished) {
        $InstallTimer.Stop()
        $ans = [System.Windows.Forms.MessageBox]::Show(
            "Are you sure you want to abort Sub-Level 4 installation?`r`nYour `$1.50 Per Diem and Personal Pan Pizza Voucher will be forfeited!",
            "Abort Artsy_2000 Setup",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($ans -eq [System.Windows.Forms.DialogResult]::Yes) {
            $Form.Close()
        } else {
            $InstallTimer.Start()
        }
    } else {
        $Form.Close()
    }
})

$Form.Add_FormClosing({
    $InstallTimer.Stop()
})

# Pop the setup window strictly in front of Windows Explorer after double-clicking SETUP.BAT
if (-not ([System.Management.Automation.PSTypeName]'BuckFifty.Win32FocusHelper').Type) {
    Add-Type -Name Win32FocusHelper -Namespace BuckFifty -MemberDefinition @'
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(System.IntPtr hWnd);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool BringWindowToTop(System.IntPtr hWnd);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);
'@ -ErrorAction SilentlyContinue
}

$Form.Add_Shown({
    if ($Form.Location.X -lt -2000) { return }
    $Form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $Form.TopMost = $true
    $Form.BringToFront()
    $Form.Activate()
    try {
        [BuckFifty.Win32FocusHelper]::ShowWindow($Form.Handle, 9) | Out-Null
        [BuckFifty.Win32FocusHelper]::BringWindowToTop($Form.Handle) | Out-Null
        [BuckFifty.Win32FocusHelper]::SetForegroundWindow($Form.Handle) | Out-Null
    } catch {}
    $script:FocusReleaseTimer = New-Object System.Windows.Forms.Timer
    $script:FocusReleaseTimer.Interval = 150
    $script:FocusReleaseTimer.Add_Tick({
        $script:FocusReleaseTimer.Stop()
        $script:FocusReleaseTimer.Dispose()
        $Form.TopMost = $false
        $Form.Activate()
        $BtnNext.Focus()
    })
    $script:FocusReleaseTimer.Start()
})

Show-WizardPage 0
[void]$Form.ShowDialog()
