@echo off
title Buck-Fifty Innovation Labs - Artsy_2000 Setup Wizard (1996)
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "%~dp0DATA\SETUP.PS1"
