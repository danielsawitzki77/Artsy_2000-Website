ARTSY_2000 — PRESS KIT ASSET USAGE GUIDE
========================================

All screenshots, logos, key art, POV-Ray renders, pipeline mockups, and text
contained in this archive are cleared for editorial, review, news, streaming,
YouTube thumbnail, and event/festival coverage of Artsy_2000 (Buck-Fifty
Innovation Labs).

- Steam Store:    https://store.steampowered.com/app/5641470/
- Official Site:  https://buckfiftylabs.com/
- Press Kit:      https://buckfiftylabs.com/press/
- Press Contact:  info@buckfiftylabs.com

Thank you for covering Artsy_2000!
